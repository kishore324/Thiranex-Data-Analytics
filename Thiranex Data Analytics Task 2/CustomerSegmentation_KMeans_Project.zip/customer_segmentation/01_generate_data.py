"""Generate a synthetic e-commerce dataset for customer segmentation.

Outputs (in ./data):
  transactions.csv   one row per order (what a real shop's order table looks like)
  customers.csv      one row per customer (demographics)
  _ground_truth.csv  the hidden segment each customer was generated from.
                     Real data has no such column; we keep it ONLY to check that
                     K-Means can rediscover structure. Never use it as a feature.
"""
from pathlib import Path

import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)
OUT = Path(__file__).parent / "data"
OUT.mkdir(exist_ok=True)

CUTOFF = pd.Timestamp("2026-09-30")          # "today" for recency
WINDOW_START = CUTOFF - pd.Timedelta(days=364)  # 12-month analysis window
N_CUSTOMERS = 1500

CATEGORIES = ["Electronics", "Furniture", "Apparel", "Home & Kitchen", "Sports", "Stationery"]
REGIONS = ["North", "South", "East", "West"]

# Latent behaviour profiles (hidden from the model).
# orders = mean extra orders on top of 1; aov = typical order value (INR);
# recency = mean days since last order; disc = mean discount share; cat = category mix
SEGMENTS = {
    "loyal_high_value": dict(share=0.18, orders=13, aov=6500, recency=12, disc=0.05,
                             cat=[.30, .15, .15, .20, .10, .10], age=(38, 7), income=(1800, 400)),
    "big_ticket":       dict(share=0.12, orders=2.5, aov=24000, recency=60, disc=0.08,
                             cat=[.55, .35, .02, .05, .02, .01], age=(42, 8), income=(2400, 500)),
    "bargain_hunter":   dict(share=0.25, orders=10, aov=1400, recency=25, disc=0.25,
                             cat=[.03, .02, .35, .10, .25, .25], age=(26, 5), income=(550, 150)),
    "lapsed":           dict(share=0.25, orders=2, aov=3500, recency=210, disc=0.12,
                             cat=[.20, .15, .20, .20, .10, .15], age=(40, 11), income=(900, 300)),
    "new_casual":       dict(share=0.20, orders=0.5, aov=2800, recency=40, disc=0.10,
                             cat=[.20, .10, .25, .20, .15, .10], age=(29, 7), income=(800, 250)),
}

cust_rows, txn_rows, truth_rows = [], [], []
order_id = 100000
names = list(SEGMENTS)
shares = np.array([SEGMENTS[n]["share"] for n in names])
assignments = RNG.choice(names, size=N_CUSTOMERS, p=shares / shares.sum())

for i, seg in enumerate(assignments, start=1):
    p = SEGMENTS[seg]
    cid = f"C{i:05d}"

    # --- demographics -------------------------------------------------
    age = int(np.clip(RNG.normal(*p["age"]), 18, 75))
    income = float(np.clip(RNG.normal(*p["income"]), 200, None))  # thousand INR / year
    cust_rows.append(dict(
        CustomerID=cid, Age=age, Gender=RNG.choice(["F", "M"], p=[.5, .5]),
        Region=RNG.choice(REGIONS), AnnualIncome_kINR=round(income, 0)))
    truth_rows.append(dict(CustomerID=cid, TrueSegment=seg))

    # --- order dates --------------------------------------------------
    n_orders = 1 + RNG.poisson(p["orders"])
    recency = int(np.clip(RNG.exponential(p["recency"]), 0, 360))
    if seg == "lapsed":
        recency = int(np.clip(RNG.normal(p["recency"], 50), 90, 360))
    last = CUTOFF - pd.Timedelta(days=recency)
    # new customers only started buying recently
    first_floor = CUTOFF - pd.Timedelta(days=int(RNG.integers(15, 120))) if seg == "new_casual" else WINDOW_START
    first_floor = min(first_floor, last)
    span = max((last - first_floor).days, 0)
    offsets = np.sort(RNG.integers(0, span + 1, size=max(n_orders - 1, 0)))
    dates = [first_floor + pd.Timedelta(days=int(o)) for o in offsets] + [last]

    # --- each order ---------------------------------------------------
    for d in dates:
        order_id += 1
        cat = RNG.choice(CATEGORIES, p=np.array(p["cat"]) / sum(p["cat"]))
        value = float(RNG.lognormal(np.log(p["aov"]), 0.45))
        disc = float(np.clip(RNG.beta(2, 2 / max(p["disc"], 0.01) - 2 + 0.0001), 0, 0.6))
        txn_rows.append(dict(
            OrderID=f"ORD{order_id}", CustomerID=cid, OrderDate=d.date(),
            Category=cat, Discount=round(disc, 3),
            OrderValue=round(value * (1 - disc), 2),
            Channel=RNG.choice(["Online", "Store"], p=[.7, .3] if seg in ("bargain_hunter", "new_casual") else [.5, .5])))

customers = pd.DataFrame(cust_rows)
txns = pd.DataFrame(txn_rows).sort_values("OrderDate").reset_index(drop=True)
truth = pd.DataFrame(truth_rows)

customers.to_csv(OUT / "customers.csv", index=False)
txns.to_csv(OUT / "transactions.csv", index=False)
truth.to_csv(OUT / "_ground_truth.csv", index=False)

print(f"customers={len(customers):,}  orders={len(txns):,}")
print(f"order dates {txns.OrderDate.min()} to {txns.OrderDate.max()}")
print(f"total revenue INR {txns.OrderValue.sum():,.0f}")
print(truth.TrueSegment.value_counts().to_string())
