# Customer Segmentation with K-Means (Python + scikit-learn)

Group 1,500 e-commerce customers into behavioural segments from their purchase history, profile each segment, and turn the segments into targeted marketing actions.

**Outcome:** hands-on practice in customer analytics, segmentation (RFM + K-Means), and targeted insights.

> **Note on the source video:** the video page could not be opened from my environment, so this project is built from the Key Features / Expected Outcome you gave (K-Means in scikit-learn, purchase patterns and preferences, visualised segments), not from the presenter's exact steps or dataset. If you share the transcript or the dataset it uses, the pipeline can be adapted to match.

---

## 1. What is in this folder

```
customer_segmentation/
├── README.md                    <- this guide
├── requirements.txt
├── 01_generate_data.py          <- builds the synthetic dataset
├── 02_segmentation.py           <- the full K-Means pipeline
├── data/
│   ├── transactions.csv         <- 10,337 orders (Oct 2025 - Sep 2026)
│   ├── customers.csv            <- 1,500 customers (age, gender, region, income)
│   └── _ground_truth.csv        <- hidden generating segments, for validation only
└── output/
    ├── customers_segmented.csv  <- each customer + their segment + features
    ├── segment_profile.csv
    ├── Customer_Segments.xlsx   <- profile, category mix, customer list (for Excel / Power BI)
    ├── kmeans_model.joblib      <- fitted scaler + model
    ├── run_log.txt              <- full console output of the run
    └── charts/ 01..05 *.png
```

Run it:

```bash
pip install -r requirements.txt
python3 01_generate_data.py     # optional: data is already included
python3 02_segmentation.py      # K=4 python3 02_segmentation.py to force a different k
```

## 2. Method, step by step

| Step | What the code does | Why |
|---|---|---|
| 1. Feature engineering | Turns the order table into one row per customer: **Recency** (days since last order), **Frequency** (orders in 12 months), **Monetary** (total spend), **Avg order value**, **Avg discount**, **Categories bought** | RFM is the standard base for customer segmentation. Discount and category breadth add *preference* information |
| 2. Transform and scale | `log1p` on Frequency and Avg order value, then `StandardScaler` | K-Means uses distances, so a column measured in thousands of rupees would swamp one measured in days. Log tames the long right tail |
| 3. Drop Monetary from the model | Monetary is kept only for profiling | Monetary = Frequency x Avg order value, so using all three would count spend three times |
| 4. Choose k | Elbow (inertia) and silhouette for k = 2..9 | Elbow shows where gains flatten; silhouette measures how well separated the clusters are |
| 5. Fit | `KMeans(n_init=20, random_state=42)` | 20 restarts avoid a bad random start |
| 6. Validate | Re-fit with 10 other seeds and compare (adjusted Rand index); compare to the hidden generating segments | Checks the segments are stable, not an accident of one seed |
| 7. Profile and name | Average of each feature per segment, share of customers vs share of revenue, category mix | A cluster only matters if you can describe it and act on it |
| 8. Visualise | Charts 01 to 05 (below) | |

## 3. Results

**Model quality (from `output/run_log.txt`):** silhouette peaks at **k = 5 (0.533)**. Re-fitting with 10 different seeds gives identical clusters (stability ARI = 1.00).

| Segment | Customers | Revenue share | Recency (days) | Orders / yr | Avg order (INR) | Avg discount | Categories | Total spend (INR) |
|---|---|---|---|---|---|---|---|---|
| Loyal Champions | 293 (20%) | 55% | 10 | 14.1 | 7,005 | 5% | 5.3 | 97,644 |
| Big-Ticket Buyers | 153 (10%) | 25% | 54 | 3.5 | 24,199 | 8% | 2.0 | 84,348 |
| Bargain Hunters | 378 (25%) | 9% | 23 | 10.8 | 1,190 | 25% | 4.0 | 12,759 |
| New & Casual | 315 (21%) | 3% | 41 | 1.5 | 2,785 | 9% | 1.4 | 4,326 |
| Lapsed / At-Risk | 361 (24%) | 8% | 206 | 3.0 | 3,569 | 12% | 2.4 | 10,723 |

Total revenue in the window: INR 5.16 crore (51,571,980).

**Charts**

| File | Shows |
|---|---|
| `01_choose_k.png` | Elbow and silhouette curves |
| `02_segments_pca.png` | 2-D map of customers, one panel per segment (segment in colour, everyone else grey) |
| `03_size_vs_revenue.png` | Share of customers vs share of revenue |
| `04_segment_profile.png` | Heatmap of each segment vs the all-customer average, with real values |
| `05_category_mix.png` | What each segment buys |

## 4. Insights and targeted actions

1. **Two segments carry the business.** Loyal Champions and Big-Ticket Buyers are 30% of customers but roughly 80% of revenue. Protecting them matters more than any other action.
2. **Loyal Champions** buy often (14 orders), recently (10 days), across 5+ categories, and rarely use discounts. *Action:* early access, loyalty tiers and cross-sell, not discounts, since they already buy at near-full price.
3. **Big-Ticket Buyers** buy few, expensive items (55% Electronics, 33% Furniture). *Action:* accessories and warranties, financing/EMI offers, and a reminder timed to a typical replacement cycle.
4. **Bargain Hunters** are 25% of customers but 9% of revenue, with a 25% average discount and mostly Apparel, Sports and Stationery. *Action:* bundles and minimum-basket offers to raise order value, rather than deeper blanket discounts. Check margin before pushing volume.
5. **New & Casual** have bought about 1.5 times. *Action:* a second-purchase journey (welcome series, a recommendation in the category they bought).
6. **Lapsed / At-Risk** last bought about 206 days ago and are 24% of customers. *Action:* a win-back campaign; test a small incentive on a holdout group first.

These actions are hypotheses to A/B test, not guaranteed results.

## 5. Honest caveats

- **The data is synthetic.** It was generated from five behaviour profiles, so the clusters are cleaner than real data. A silhouette of 0.53 and a 0.94 match to the hidden segments are optimistic; real customer data often scores lower and has overlapping groups.
- `_ground_truth.csv` exists only to check the method. Real projects have no such column, and you must never feed it to the model.
- K-Means assumes roughly round, similar-sized clusters and is sensitive to scaling and outliers. If your own data disagrees, try Gaussian mixtures, hierarchical clustering or DBSCAN.
- Segment names come from simple rules on the cluster averages and only apply when k = 5. With another k the script labels segments "Segment 1..k" and you name them yourself.
- Recency is measured from a fixed date (2026-09-30). Re-run with a new date as time passes.

## 6. Using the model on a new customer

```python
import joblib, numpy as np, pandas as pd
m = joblib.load("output/kmeans_model.joblib")
new = pd.DataFrame([{"Recency": 15, "LogFrequency": np.log1p(12),
                     "LogAOV": np.log1p(6000), "AvgDiscount": 0.05, "NumCategories": 5}])
label = m["kmeans"].predict(m["scaler"].transform(new[m["model_cols"]]))[0]
print(m["names"][label])
```

## 7. Power BI option

The source notes mention Power BI as an alternative. Clustering is already done in Python, so load `output/Customer_Segments.xlsx` (sheets: Segment Profile, Category Mix %, Customers) and build:

- **Cards:** customer count, total revenue, average order value
- **Bar charts:** customers and revenue by Segment
- **Slicers:** Segment, Region, Gender, Age band
- **Table:** top customers per segment by Monetary

Useful measures:

```DAX
Customers = DISTINCTCOUNT(Customers[CustomerID])
Revenue = SUM(Customers[Monetary])
Revenue Share = DIVIDE([Revenue], CALCULATE([Revenue], ALL(Customers[Segment])))
Avg Recency = AVERAGE(Customers[Recency])
```

Power BI also has a built-in **Clustering** option on scatter plots (Analytics pane), which is a quick way to compare against your Python result.

## 8. Ideas to extend

- Replace the synthetic data with a real dataset (for example the public Online Retail or Mall Customers datasets) and compare silhouette scores.
- Try 3-D RFM clustering vs the 5-feature version and compare stability.
- Add Gaussian mixture models and compare segments.
- Track each customer's segment month by month to see who moves from New to Loyal, or from Loyal to Lapsed.
