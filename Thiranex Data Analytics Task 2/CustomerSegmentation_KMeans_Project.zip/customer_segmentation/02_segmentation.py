"""Customer segmentation with K-Means (RFM + behaviour features).

Run:  python3 02_segmentation.py            (k picked by silhouette)
      K=4 python3 02_segmentation.py        (force a different k)

Steps
  1. Build one row per customer from the order table (RFM + behaviour features)
  2. Transform skewed columns, standardise
  3. Choose k (elbow + silhouette)
  4. Fit K-Means, check stability
  5. Profile and name the segments
  6. Charts + exports
"""
import os
from pathlib import Path

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.preprocessing import StandardScaler

HERE = Path(__file__).parent
DATA, OUT, FIG = HERE / "data", HERE / "output", HERE / "output" / "charts"
FIG.mkdir(parents=True, exist_ok=True)
SEED = 42
CUTOFF = pd.Timestamp("2026-09-30")

# ----------------------------------------------------------------------------
# 1. Features: one row per customer
# ----------------------------------------------------------------------------
txn = pd.read_csv(DATA / "transactions.csv", parse_dates=["OrderDate"])
cust = pd.read_csv(DATA / "customers.csv")

g = txn.groupby("CustomerID")
feat = pd.DataFrame({
    "Recency": (CUTOFF - g.OrderDate.max()).dt.days,          # days since last order
    "Frequency": g.OrderID.nunique(),                          # orders in 12 months
    "Monetary": g.OrderValue.sum(),                            # total spend (INR)
    "AvgDiscount": g.Discount.mean(),                          # share of list price given away
    "NumCategories": g.Category.nunique(),                     # breadth of shopping
    "TopCategory": g.Category.agg(lambda s: s.mode().iat[0]),
    "OnlineShare": g.Channel.apply(lambda s: (s == "Online").mean()),
})
feat["AvgOrderValue"] = feat.Monetary / feat.Frequency
df = feat.join(cust.set_index("CustomerID")).reset_index()

print("=== 1. Feature table ===")
print(df[["Recency", "Frequency", "Monetary", "AvgOrderValue", "AvgDiscount", "NumCategories"]]
      .describe().round(2).T[["mean", "50%", "min", "max"]].to_string())
print("missing values:", int(df.isna().sum().sum()))

# ----------------------------------------------------------------------------
# 2. Transform + scale
#    Frequency and AOV are right-skewed -> log1p. Monetary = Frequency x AOV, so
#    using all three would triple-count spend; Monetary is kept for profiling only.
# ----------------------------------------------------------------------------
MODEL_COLS = ["Recency", "LogFrequency", "LogAOV", "AvgDiscount", "NumCategories"]
df["LogFrequency"] = np.log1p(df.Frequency)
df["LogAOV"] = np.log1p(df.AvgOrderValue)
scaler = StandardScaler()
X = scaler.fit_transform(df[MODEL_COLS])

# ----------------------------------------------------------------------------
# 3. Choose k
# ----------------------------------------------------------------------------
ks = list(range(2, 10))
inertia, sil = [], []
for k in ks:
    km = KMeans(n_clusters=k, n_init=20, random_state=SEED).fit(X)
    inertia.append(km.inertia_)
    sil.append(silhouette_score(X, km.labels_))
best_k = ks[int(np.argmax(sil))]
K = int(os.environ.get("K", best_k))
print("\n=== 3. Choosing k ===")
print(pd.DataFrame({"k": ks, "inertia": np.round(inertia), "silhouette": np.round(sil, 3)}).to_string(index=False))
print(f"best silhouette at k={best_k}; using k={K}")

# ----------------------------------------------------------------------------
# 4. Fit + stability
# ----------------------------------------------------------------------------
km = KMeans(n_clusters=K, n_init=20, random_state=SEED).fit(X)
df["Cluster"] = km.labels_
aris = [adjusted_rand_score(km.labels_, KMeans(n_clusters=K, n_init=20, random_state=s).fit(X).labels_)
        for s in range(1, 11)]
print(f"\n=== 4. Fit ===\nsilhouette={silhouette_score(X, km.labels_):.3f}  "
      f"stability (mean ARI over 10 reseeds)={np.mean(aris):.3f}")

truth = pd.read_csv(DATA / "_ground_truth.csv")
df = df.merge(truth, on="CustomerID")
print(f"agreement with hidden generating segments (ARI)={adjusted_rand_score(df.TrueSegment, df.Cluster):.3f}")
print(pd.crosstab(df.Cluster, df.TrueSegment).to_string())

# ----------------------------------------------------------------------------
# 5. Profile + name segments
# ----------------------------------------------------------------------------
prof = df.groupby("Cluster").agg(
    Customers=("CustomerID", "count"), Recency=("Recency", "mean"), Frequency=("Frequency", "mean"),
    AvgOrderValue=("AvgOrderValue", "mean"), AvgDiscount=("AvgDiscount", "mean"),
    NumCategories=("NumCategories", "mean"), Monetary=("Monetary", "mean"),
    Revenue=("Monetary", "sum"), Age=("Age", "mean"), Income_kINR=("AnnualIncome_kINR", "mean"),
    OnlineShare=("OnlineShare", "mean"))
prof["CustomerShare"] = prof.Customers / prof.Customers.sum()
prof["RevenueShare"] = prof.Revenue / prof.Revenue.sum()


def name_segments(p: pd.DataFrame) -> dict:
    """Rule-based names, assigned by what makes each cluster stand out. Only valid for k=5."""
    if len(p) != 5:
        return {c: f"Segment {c + 1}" for c in p.index}
    left, names = set(p.index), {}
    for label, col in [("Lapsed / At-Risk", "Recency"), ("Big-Ticket Buyers", "AvgOrderValue"),
                       ("Loyal Champions", "Monetary"), ("Bargain Hunters", "AvgDiscount")]:
        c = p.loc[sorted(left), col].idxmax()
        names[c] = label
        left.discard(c)
    names[left.pop()] = "New & Casual"
    return names


names = name_segments(prof)
df["Segment"] = df.Cluster.map(names)
prof.insert(0, "Segment", prof.index.map(names))
ORDER = [n for n in ["Loyal Champions", "Big-Ticket Buyers", "Bargain Hunters", "New & Casual", "Lapsed / At-Risk"]
         if n in set(names.values())] or sorted(set(names.values()))
prof = prof.set_index("Segment").loc[ORDER]
cat_mix = (pd.crosstab(df.Segment, txn.merge(df[["CustomerID", "Segment"]], on="CustomerID").Category)
           if False else
           pd.crosstab(txn.merge(df[["CustomerID", "Segment"]], on="CustomerID").Segment,
                       txn.merge(df[["CustomerID", "Segment"]], on="CustomerID").Category, normalize="index")
           ).loc[ORDER]

pd.set_option("display.width", 200)
print("\n=== 5. Segment profile ===")
print(prof[["Customers", "CustomerShare", "RevenueShare", "Recency", "Frequency", "AvgOrderValue",
            "AvgDiscount", "NumCategories", "Monetary", "OnlineShare"]].round(2).to_string())
print("\nCategory mix (share of orders):")
print((cat_mix * 100).round(0).to_string())

# ----------------------------------------------------------------------------
# 6. Charts  (validated categorical slots, fixed order = fixed entity colour)
# ----------------------------------------------------------------------------
SLOTS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]
COLOR = {n: SLOTS[i] for i, n in enumerate(ORDER)}
SURFACE, INK, INK2, MUTED, GRID, BASE = "#fcfcfb", "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"
plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "text.color": INK, "axes.labelcolor": INK2, "xtick.color": MUTED, "ytick.color": MUTED,
    "axes.edgecolor": BASE, "axes.spines.top": False, "axes.spines.right": False,
    "font.size": 10, "axes.titlesize": 11, "axes.titleweight": "bold", "axes.titlelocation": "left",
})


def save(fig, name):
    fig.savefig(FIG / name, dpi=160, bbox_inches="tight")
    plt.close(fig)


# 6.1 elbow + silhouette (one measure per panel, no dual axis)
fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
for a, ys, title, ylab in [(ax[0], inertia, "Elbow: inertia", "Within-cluster sum of squares"),
                           (ax[1], sil, "Silhouette score (higher is better)", "Silhouette")]:
    a.plot(ks, ys, color=SLOTS[0], lw=2, marker="o", ms=6, mfc=SURFACE, mec=SLOTS[0], mew=2)
    a.axvline(K, color=MUTED, lw=1, ls=(0, (4, 3)))
    a.set_title(title)
    a.set_xlabel("Number of clusters (k)")
    a.set_ylabel(ylab)
    a.set_xticks(ks)
    a.grid(axis="y", color=GRID, lw=0.8)
    a.set_axisbelow(True)
ax[0].annotate(f"k={K}", (K, inertia[ks.index(K)]), xytext=(8, 8), textcoords="offset points", color=INK2)
ax[1].annotate(f"k={K}: {sil[ks.index(K)]:.2f}", (K, sil[ks.index(K)]), xytext=(8, -14),
               textcoords="offset points", color=INK2)
save(fig, "01_choose_k.png")

# 6.2 PCA map: one panel per segment (the segment in colour, everyone else in grey)
pca = PCA(n_components=2, random_state=SEED)
pts = pca.fit_transform(X)
ev = pca.explained_variance_ratio_
fig, axes = plt.subplots(1, len(ORDER), figsize=(3.3 * len(ORDER), 3.6), sharex=True, sharey=True)
for a, seg in zip(np.atleast_1d(axes), ORDER):
    m = (df.Segment == seg).to_numpy()
    a.scatter(pts[~m, 0], pts[~m, 1], s=6, color=BASE, alpha=0.45, linewidths=0)
    a.scatter(pts[m, 0], pts[m, 1], s=11, color=COLOR[seg], alpha=0.9, linewidths=0.4, edgecolors=SURFACE)
    a.set_title(f"{seg}\n{m.sum():,} customers", fontsize=10)
    a.set_xlabel(f"PC1 ({ev[0]:.0%} of variance)")
    a.grid(color=GRID, lw=0.6)
    a.set_axisbelow(True)
np.atleast_1d(axes)[0].set_ylabel(f"PC2 ({ev[1]:.0%})")
save(fig, "02_segments_pca.png")

# 6.3 size vs revenue
fig, ax = plt.subplots(1, 2, figsize=(10, 3.4), sharey=True)
for a, col, title in [(ax[0], "CustomerShare", "Share of customers"), (ax[1], "RevenueShare", "Share of revenue")]:
    vals = prof[col].loc[ORDER]
    bars = a.barh(range(len(ORDER)), vals, color=[COLOR[s] for s in ORDER], height=0.62)
    for i, v in enumerate(vals):
        a.text(v + 0.006, i, f"{v:.0%}", va="center", color=INK, fontsize=10)
    a.set_title(title)
    a.set_xlim(0, max(prof.CustomerShare.max(), prof.RevenueShare.max()) * 1.18)
    a.xaxis.set_visible(False)
    a.spines["bottom"].set_visible(False)
    a.set_yticks(range(len(ORDER)))
    a.set_yticklabels(ORDER, color=INK)
    a.tick_params(axis="y", length=0)
ax[0].invert_yaxis()  # shared y-axis: invert once, not once per panel
save(fig, "03_size_vs_revenue.png")

# 6.4 profile heatmap: how far each segment sits from the all-customer average
cols = ["Recency", "Frequency", "AvgOrderValue", "AvgDiscount", "NumCategories", "Monetary"]
labels = ["Recency\n(days)", "Orders\n(12 mo)", "Avg order\nvalue (INR)", "Avg\ndiscount", "Categories\nbought", "Total spend\n(INR)"]
fmt = [lambda v: f"{v:.0f}", lambda v: f"{v:.1f}", lambda v: f"{v:,.0f}", lambda v: f"{v:.0%}",
       lambda v: f"{v:.1f}", lambda v: f"{v:,.0f}"]
overall_mu, overall_sd = df[cols].mean(), df[cols].std()
Z = ((prof[cols] - overall_mu) / overall_sd).loc[ORDER]
cmap = LinearSegmentedColormap.from_list("div", ["#2a78d6", "#f0efec", "#e34948"])
fig, a = plt.subplots(figsize=(10, 0.8 * len(ORDER) + 1.6))
a.imshow(Z.values, cmap=cmap, vmin=-1.6, vmax=1.6, aspect="auto")
for i, seg in enumerate(ORDER):
    for j, c in enumerate(cols):
        z = Z.iloc[i, j]
        a.text(j, i, fmt[j](prof.loc[seg, c]), ha="center", va="center", fontsize=10,
               color="white" if abs(z) > 1.1 else INK)
a.set_xticks(range(len(cols)))
a.set_xticklabels(labels, color=INK2)
a.set_yticks(range(len(ORDER)))
a.set_yticklabels(ORDER, color=INK)
a.xaxis.tick_top()
a.tick_params(length=0)
for s in a.spines.values():
    s.set_visible(False)
a.set_xticks(np.arange(-.5, len(cols), 1), minor=True)
a.set_yticks(np.arange(-.5, len(ORDER), 1), minor=True)
a.grid(which="minor", color=SURFACE, lw=3)
a.tick_params(which="minor", length=0)
a.set_title("Segment profile (blue = below average, red = above average)", pad=34)
save(fig, "04_segment_profile.png")

# 6.5 category preference
fig, a = plt.subplots(figsize=(9, 0.7 * len(ORDER) + 1.6))
seq = LinearSegmentedColormap.from_list("seq", ["#cde2fb", "#2a78d6", "#0d366b"])
a.imshow(cat_mix.values, cmap=seq, vmin=0, vmax=0.6, aspect="auto")
for i in range(cat_mix.shape[0]):
    for j in range(cat_mix.shape[1]):
        v = cat_mix.iloc[i, j]
        a.text(j, i, f"{v:.0%}", ha="center", va="center", fontsize=10, color="white" if v > 0.3 else INK)
a.set_xticks(range(cat_mix.shape[1]))
a.set_xticklabels(cat_mix.columns, color=INK2)
a.set_yticks(range(len(ORDER)))
a.set_yticklabels(ORDER, color=INK)
a.xaxis.tick_top()
a.tick_params(length=0)
for s in a.spines.values():
    s.set_visible(False)
a.set_xticks(np.arange(-.5, cat_mix.shape[1], 1), minor=True)
a.set_yticks(np.arange(-.5, len(ORDER), 1), minor=True)
a.grid(which="minor", color=SURFACE, lw=3)
a.tick_params(which="minor", length=0)
a.set_title("What each segment buys (share of orders by category)", pad=34)
save(fig, "05_category_mix.png")

# ----------------------------------------------------------------------------
# 7. Exports
# ----------------------------------------------------------------------------
keep = ["CustomerID", "Segment", "Recency", "Frequency", "Monetary", "AvgOrderValue", "AvgDiscount",
        "NumCategories", "TopCategory", "OnlineShare", "Age", "Gender", "Region", "AnnualIncome_kINR"]
out = df[keep].round(3)
out.to_csv(OUT / "customers_segmented.csv", index=False)
prof_out = prof.drop(columns=["Customers", "Revenue"]).assign(Customers=prof.Customers, Revenue=prof.Revenue.round(0)).round(3)
prof_out.to_csv(OUT / "segment_profile.csv")
with pd.ExcelWriter(OUT / "Customer_Segments.xlsx") as xw:
    prof_out.to_excel(xw, sheet_name="Segment Profile")
    (cat_mix * 100).round(1).to_excel(xw, sheet_name="Category Mix %")
    out.to_excel(xw, sheet_name="Customers", index=False)
joblib.dump({"scaler": scaler, "kmeans": km, "model_cols": MODEL_COLS, "names": names}, OUT / "kmeans_model.joblib")
print(f"\nSaved to {OUT}")
