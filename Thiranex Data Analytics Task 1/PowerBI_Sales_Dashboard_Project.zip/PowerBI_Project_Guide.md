# Project: Sales Performance Dashboard in Power BI

**Goal:** Import sales data, track KPIs (total sales, revenue trends, top products), and build an interactive dashboard with charts, filters and slicers, then turn it into business insights.

**Dataset (included):** 3 tables, Jan 2024 to Sep 2026, 4,088 orders, 15 products, 168 customers across 4 regions.

| File | Columns |
|---|---|
| Sales.csv | OrderID, OrderDate, CustomerID, ProductID, Quantity, Discount, PaymentMethod |
| Products.csv | ProductID, ProductName, Category, UnitPrice, UnitCost |
| Customers.csv | CustomerID, CustomerName, Segment, Region, City |

Sales_Data.xlsx holds the same three tables as sheets. Use it to practise importing from Excel; use the CSVs to practise importing from CSV.

---

## Phase 1: Import data (Get Data)

1. Open Power BI Desktop, then **Home > Get Data > Text/CSV** and load `Sales.csv`, `Products.csv` and `Customers.csv`. Choose **Transform Data** instead of Load.
2. Practise a second source: **Get Data > Excel workbook** and load `Sales_Data.xlsx`. (A database such as SQL Server or PostgreSQL works the same way via **Get Data > SQL Server**.)
3. In Power Query, check:
   - `OrderDate` is type **Date**
   - `Quantity` is **Whole number**
   - `Discount`, `UnitPrice`, `UnitCost` are **Decimal number**
   - No nulls or duplicate OrderIDs (the file is clean, so this is a quick check)
4. **Close & Apply**.

## Phase 2: Data model

1. Create a Date table (Modeling > New table):

```DAX
Calendar =
ADDCOLUMNS(
    CALENDAR(DATE(2024,1,1), DATE(2026,12,31)),
    "Year", YEAR([Date]),
    "Month No", MONTH([Date]),
    "Month", FORMAT([Date], "MMM"),
    "Quarter", "Q" & QUARTER([Date]),
    "Year-Month", FORMAT([Date], "YYYY-MM")
)
```

Mark it as a date table: **Table tools > Mark as date table**, using `Date`.

2. Build a star schema in **Model view**. Every relationship is one-to-many, single direction, from the dimension to Sales:

   - `Products[ProductID]` to `Sales[ProductID]`
   - `Customers[CustomerID]` to `Sales[CustomerID]`
   - `Calendar[Date]` to `Sales[OrderDate]`

## Phase 3: DAX measures (the KPIs)

Create a table called `_Measures` (Enter Data, blank) to hold these.

```DAX
Total Revenue =
SUMX(Sales, Sales[Quantity] * RELATED(Products[UnitPrice]) * (1 - Sales[Discount]))

Total Cost =
SUMX(Sales, Sales[Quantity] * RELATED(Products[UnitCost]))

Total Profit = [Total Revenue] - [Total Cost]

Profit Margin % = DIVIDE([Total Profit], [Total Revenue])

Total Orders = DISTINCTCOUNT(Sales[OrderID])

Units Sold = SUM(Sales[Quantity])

Avg Order Value = DIVIDE([Total Revenue], [Total Orders])

Revenue LY =
CALCULATE([Total Revenue], SAMEPERIODLASTYEAR('Calendar'[Date]))

YoY Growth % = DIVIDE([Total Revenue] - [Revenue LY], [Revenue LY])

Revenue YTD =
TOTALYTD([Total Revenue], 'Calendar'[Date])

Revenue MoM % =
VAR Prev = CALCULATE([Total Revenue], DATEADD('Calendar'[Date], -1, MONTH))
RETURN DIVIDE([Total Revenue] - Prev, Prev)

Product Rank =
RANKX(ALL(Products[ProductName]), [Total Revenue], , DESC)

Revenue Share % =
DIVIDE([Total Revenue], CALCULATE([Total Revenue], ALLSELECTED(Products)))
```

## Phase 4: Report layout (single page, 16:9)

Set **View > Page view > Fit to page**. Use this layout:

```
+-------------------------------------------------------------+
| Title: Sales Performance Dashboard          [Year] [Region] |
+-------------------------------------------------------------+
| Revenue | Profit | Margin % | Orders | Avg Order | YoY %    |  <- 6 KPI cards
+-------------------------------+-----------------------------+
| Revenue trend (line, by month)| Revenue by Category (donut) |
|  + Revenue LY as 2nd line     |                             |
+-------------------------------+-----------------------------+
| Top 10 products (bar, Top N)  | Revenue by Region (map/bar) |
+-------------------------------+-----------------------------+
| Segment slicer | Category slicer | Payment method (column)  |
+-------------------------------------------------------------+
```

| Visual | Fields | Notes |
|---|---|---|
| KPI cards (x6) | Total Revenue, Total Profit, Profit Margin %, Total Orders, Avg Order Value, YoY Growth % | Use the **Card (new)** visual with a reference label |
| Line chart | X: `Calendar[Year-Month]`, Y: Total Revenue, Revenue LY | Shows seasonality and trend |
| Donut | Legend: `Products[Category]`, Values: Total Revenue | Keep to 6 slices or fewer |
| Bar chart | Y: `Products[ProductName]`, X: Total Revenue | **Filters pane > Top N = 10** by Total Revenue |
| Filled map or bar | `Customers[Region]` / `Customers[City]` | Tooltip with margin % |
| Column chart | `Sales[PaymentMethod]`, Orders | Payment mix |
| Slicers | `Calendar[Year]` (tile), `Customers[Region]` (tile), `Customers[Segment]` (dropdown), `Products[Category]` (list) | **View > Sync slicers** if you add pages |

**Interactivity:**
- Add a tooltip page showing profit and margin for the hovered item.
- Add a drill-through page for a single product (right-click a product bar > Drill through).
- Add a bookmark button to reset all filters.
- Add conditional formatting: red/green on YoY Growth %.

## Phase 5: Make it beautiful

- **Palette:** 1 neutral background (`#F4F6F8`), 1 accent (`#1F6FEB`), 1 highlight for "good" (`#2DA44E`) and 1 for "bad" (`#CF222E`). Use accent colors sparingly.
- **Typography:** one font family (Segoe UI), title 20pt, card values 28pt, labels 10 to 12pt.
- **Layout:** align visuals to a grid (Format > Align), equal 10px gaps, rounded corners on all visuals, whitespace around the KPI row.
- **Clutter:** turn off gridlines, hide axis titles that are obvious, show data labels only where they help.
- **Theme:** save your colors as a JSON theme (View > Themes > Customize current theme) so the whole report stays consistent.
- **Mobile:** View > Mobile layout, then drag KPI cards and 2 charts into the phone canvas.

## Phase 6: Publish and share

1. **Home > Publish** to a workspace in Power BI Service (a free account works for My workspace).
2. In the Service, open the report and **Pin** your key visuals to a new dashboard.
3. Set **Scheduled refresh** if the source is a database.
4. Share via link, or export to PDF/PowerPoint.

---

## Phase 7: Business insights to write up

The dataset was generated with a built-in festive-season peak (Oct to Nov) and uneven product popularity. Other patterns (regions, segments, discounts, payments) are random, so report what your dashboard actually shows rather than assuming a pattern. Write one sentence per finding with a recommended action.

Reference numbers from the full dataset (all periods, after discounts):

| Metric | Value |
|---|---|
| Total revenue | INR 9.12 crore (91,216,322) |
| Total profit | INR 1.67 crore (16,733,142) |
| Profit margin | 18.3% |
| Orders | 4,088 |
| Top product | Laptop Pro 14: INR 3.65 crore (about 40% of revenue) |
| #2 and #3 | Smartphone X (INR 2.34 crore), Smart Watch (INR 59 lakh) |
| Top category | Electronics: INR 6.94 crore (about 76% of revenue) |

**Questions to answer:**
1. **Concentration risk:** two products drive about 65% of revenue. What happens to the business if Laptop sales dip 10%?
2. **Seasonality:** compare Oct to Nov against Jan to Sep (data ends Sep 2026, so compare by year, not by total). Is the festive peak visible in both 2024 and 2025? What does that mean for inventory and ad spend?
3. **Margin vs revenue:** low-priced categories (Stationery, Sports) have high margins but tiny revenue. Is there a case to bundle them with Electronics orders?
4. **Discount impact:** compare Avg Order Value and margin for discounted vs non-discounted orders.
5. **Regions and segments:** which region and customer segment under-index, and is that an opportunity?
6. **Payment mix:** UPI leads. Does Cash on Delivery correlate with lower order value?

**Deliverable template (one page):**
- Headline (one sentence on overall performance)
- 3 key findings with the supporting visual
- 3 recommendations with expected impact
- Caveat: the data is synthetic and for learning

---

## Skills this project demonstrates

| Outcome | Where you practise it |
|---|---|
| Data visualization | Phases 4 and 5: chart selection, layout, theme |
| KPI tracking | Phase 3: revenue, profit, margin, YoY, YTD, MoM, ranking |
| Business insight generation | Phase 7: findings and recommendations |

## Stretch goals
- Add a **Forecast** line on the revenue chart (Analytics pane).
- Add a **Key influencers** or **Decomposition tree** visual to explain revenue drivers.
- Add **Row-level security** so each region manager sees only their region.
- Replace the CSV source with a SQL database and schedule a refresh.
